import React from 'react';
import Canvas from './Canvas';
import './App.css'; 
function App() {
  return (
    <div className="app-container">
      <header className="app-header">
        <h1 className="app-title">Drag and Drop UI</h1>
      </header>
      <main className="app-main">
        <Canvas />
      </main>
    </div>
  );
}

export default App;
