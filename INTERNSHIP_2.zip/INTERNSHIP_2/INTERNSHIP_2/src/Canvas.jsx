import React, { useState } from 'react';
import Draggable from 'react-draggable';
import { ResizableBox } from 'react-resizable';
import ReactFlow, { MiniMap, Controls, Background } from 'react-flow-renderer';
import './Canvas.css';

const Canvas = () => {
  const [cards, setCards] = useState([]);
  const [showPopup, setShowPopup] = useState(false);
  const [selectedCard, setSelectedCard] = useState(null);
  const [inputText, setInputText] = useState('');

  const addCard = () => {
    if (inputText.trim()) {
      setCards([
        ...cards,
        { id: cards.length, text: inputText }
      ]);
      setInputText('');
    }
  };

  const handleShowMore = (card) => {
    setSelectedCard(card);
    setShowPopup(true);
  };

  const closePopup = () => {
    setShowPopup(false);
    setSelectedCard(null);
  };

  return (
    <div className="canvas-container">
      <div className="input-container">
        <input 
          type="text" 
          value={inputText} 
          onChange={(e) => setInputText(e.target.value)} 
          placeholder="Enter text for the card" 
        />
        <button onClick={addCard}>Add Card</button>
      </div>
      <div className="canvas">
        {cards.map((card, index) => (
          <Draggable key={index}>
            <ResizableBox width={200} height={100} className="box">
              <div className="card">
                <p>{card.text.slice(0, 10)}...</p>
                <button onClick={() => handleShowMore(card)}>Show More</button>
              </div>
            </ResizableBox>
          </Draggable>
        ))}
      </div>
      <ReactFlow elements={[]} style={{ width: '100%', height: '400px' }}>
        <MiniMap />
        <Controls />
        <Background />
      </ReactFlow>
      {showPopup && (
        <div className="popup">
          <div className="popup-content">
            <span className="close" onClick={closePopup}>&times;</span>
            <p>{selectedCard.text}</p>
          </div>
        </div>
      )}
    </div>
  );
};

export default Canvas;
